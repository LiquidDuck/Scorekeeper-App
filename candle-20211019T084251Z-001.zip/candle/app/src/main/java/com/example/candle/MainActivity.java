package com.example.candle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int score1;
    private int score2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    /*Functions that increase and decrease both scores using two different variables as score placeholders*/
    public void inc1(View view) {
        score1++;
        display1(score1);
        }
    public void inc2(View view) {
        score2++;
        display2(score2);
    }
    public void dec1(View view) {
        score1--;
        display1(score1);
    }
    public void dec2(View view) {
        score2--;
        display2(score2);
    }
    /*Refreshes the score shown on the text view*/
    private void display1(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.score_text1);
        quantityTextView.setText("" + number);
    }
    private void display2(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.score_text2);
        quantityTextView.setText("" + number);
    }
}
